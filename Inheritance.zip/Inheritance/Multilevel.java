package Inheritance;

class Fruits{
	void dis() {
		System.out.println("This is fruits");
	}
}

class Apple extends Fruits{
	void dis1() {
		System.out.println("This is an Apple");
	}
}

class Mango extends Apple{
	void dis2() {
		System.out.println("This is a Mango");
	}
}
public class Multilevel {

	public static void main(String[] args) {
		

	}

}
