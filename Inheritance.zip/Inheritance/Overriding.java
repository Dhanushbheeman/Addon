package Inheritance;

public class Overriding {

	public static void main(String[] args) {
		

	}

}
