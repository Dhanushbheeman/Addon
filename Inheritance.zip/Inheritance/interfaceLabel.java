package Inheritance;

public class interfaceLabel implements Label{
	public static void main(String[] args)
	{
		Britanica b=new Britanica();
		b.Poster();
		b.duration();
	}
	@override
	public void Poster() {
		     public void display();
		     public void .camera
		     
}  
//
//	public void Poster();
//	public void duration();
//}

	
}
